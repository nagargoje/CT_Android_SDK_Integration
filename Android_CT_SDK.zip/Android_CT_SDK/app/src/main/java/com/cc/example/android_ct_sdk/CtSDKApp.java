package com.cc.example.android_ct_sdk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.clevertap.android.sdk.CleverTapAPI;

import java.util.HashMap;

public class CtSDKApp extends AppCompatActivity {

    EditText username;
    EditText cust_email;
    Button loginBtn;
    Button createEventBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ct_s_d_k_app);

        loginBtn=(Button)findViewById(R.id.loginbutton);
        createEventBtn=(Button)findViewById(R.id.eventbutton);
        username=findViewById(R.id.username);
        cust_email=findViewById(R.id.emailEditText);
        String cname=username.getText().toString();
        String email=cust_email.getText().toString();

        CleverTapAPI clevertapDefaultInstance = CleverTapAPI.getDefaultInstance(getApplicationContext());
        CleverTapAPI.setDebugLevel(CleverTapAPI.LogLevel.DEBUG);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap <String, Object> userProfileUpdate=new HashMap<String, Object>();
                userProfileUpdate.put("Name", cname);
                userProfileUpdate.put("Email", email);
                clevertapDefaultInstance.onUserLogin(userProfileUpdate);
                Toast.makeText(CtSDKApp.this, "User Profile is updated", Toast.LENGTH_SHORT).show();
                System.out.println("User Profile is updated " + cname+" "+email);

            }
        });

        createEventBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap<String, Object> prodViewedEvent = new HashMap<String, Object>();
                prodViewedEvent.put("Product Name", "Mechanical Analog Blue Dial Mens Watch");
                prodViewedEvent.put("Category", "Mens Accessories");
                prodViewedEvent.put("Price", 14495);
                clevertapDefaultInstance.pushEvent("Product viewed", prodViewedEvent);
                Toast.makeText(CtSDKApp.this, "Event Pushed to CleverTap", Toast.LENGTH_SHORT).show();
                System.out.println("Event Pushed to CleverTap " +prodViewedEvent.toString());
            }
        });

    }

    @Override
    public void onBackPressed() {
        finish();
    }
}

